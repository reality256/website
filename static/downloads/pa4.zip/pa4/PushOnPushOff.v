module PushOnPushOff(input CLOCK_50, input [0:0] KEY, output [1:0] LEDR);
	wire btn;
	RisingEdgeDetector red(.clk(CLOCK_50), .in(!KEY[0]), .out(btn));
	Toggle t(.clk(CLOCK_50), .in(btn), .out(LEDR[0]));
endmodule