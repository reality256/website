module TestRED;
	reg clk, in;
	wire out;
	
	RisingEdgeDetector red(.clk(clk), .in(in), .out(out));
	
	initial begin
		clk = 0;
		repeat (32) #1 clk = !clk;
	end
	
	initial begin
		in = 0;
		#6 in = 1;
		#8 in = 0;
		#2 in = 1;
		#4 in = 0;
		#6 in = 1;
		#4 in = 0;
	end
endmodule