module Toggle(input clk, input in, output out);
	reg on = 0;
	wire next_on;
	
	always @(posedge clk)
		on <= next_on;
		
	assign next_on = in ? !on : on;
	
	assign out = on;
endmodule